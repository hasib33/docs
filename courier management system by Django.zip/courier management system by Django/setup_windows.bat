@echo off
echo ==========================================
echo Courier Management System - Setup
echo ==========================================
python -m venv venv
call venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python manage.py migrate
python manage.py seed_demo
echo.
echo Setup complete.
echo Run: venv\Scripts\activate
echo Then: python manage.py runserver
pause
