# Courier Management System

A Django-based **Courier Management System** for Customer, Admin and Courier/Delivery Agent roles.

## Implemented requirements
- Real parcel details: category, KG weight, length/width/height, fragile, emergency, special handling, description, quantity, declared value and delivery instruction.
- Sender and receiver details.
- Bangladesh-only pickup/delivery structure: division, district, area, postal code and detailed address.
- Standard / Express / Emergency delivery.
- Automatic expected delivery date (Emergency = 1 day / within 24 hours target).
- Automatic pricing using active Admin-managed Pricing Rules: weight, zone, delivery type and fragile/handling charges.
- Payment responsibility: Sender or Receiver. Both payers can use Cash on Delivery, Card/Online Payment, Mobile Banking or Bank Transfer in the simulated academic workflow.
- Courier details: email, vehicle type, current area, joining date and optional file-based profile photo.
- Delivery assignment, pickup date, expected date and charges.
- Full delivery statuses including sorting, out-for-delivery, failed and returned.
- Failed delivery reasons and return-to-sender flag.
- Delivery tracking timeline with location, time and note.
- Receiver confirmation and optional proof/signature files.
- Monthly Admin report and PDF export.

## Windows setup
```cmd
cd CourierManagementSystem
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py seed_demo
python manage.py runserver
```

Open: http://127.0.0.1:8000/

### Login pages
- Customer: `/login/`
- Delivery Agent: `/courier/login/`
- Custom Admin: `/admin-panel/login/`
- Django superuser admin: `/admin/`

### Demo accounts
- Admin: `admin / Admin@12345`
- Customer: `customer / Customer@12345`
- Courier: `courier / Courier@12345`

The provided SQLite database is retained as a starting point. **Run `python manage.py migrate` before first run** to ensure all current migrations are applied.

Payment is a simulated workflow for academic/demo purposes, not a live payment gateway. Card/Online Payment, Mobile Banking and Bank Transfer do not connect to an external provider in this version. The selected payment method is available to both Sender and Receiver. No PIN or OTP is stored.
