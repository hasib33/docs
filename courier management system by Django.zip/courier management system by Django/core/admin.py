from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User,Customer,AdminProfile,Courier,Category,Parcel,PricingRule,Order,OrderItem,Payment,Delivery,Tracking
@admin.register(User)
class CustomUserAdmin(UserAdmin):
    fieldsets=UserAdmin.fieldsets+(("Courier System",{"fields":("role","created_at")}),); readonly_fields=("created_at",)
for model in [Customer,AdminProfile,Courier,Category,Parcel,PricingRule,Order,OrderItem,Payment,Delivery,Tracking]: admin.site.register(model)
