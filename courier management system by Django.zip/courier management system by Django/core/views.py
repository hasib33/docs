from datetime import timedelta
import json
from decimal import Decimal
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import Sum, Count
from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from .decorators import role_required
from .forms import RegisterForm, ProfileForm, CategoryForm, ParcelForm, AdminSendParcelForm, OrderForm, PaymentForm, CourierCreateForm, CourierUpdateForm, PricingRuleForm
from .models import User, Customer, Courier, Category, Parcel, Order, OrderItem, Payment, Delivery, Tracking, PricingRule
from .bangladesh import BANGLADESH_DIVISIONS


def home(request): return render(request,"home.html")
def register_view(request):
    if request.user.is_authenticated: return redirect("dashboard")
    form=RegisterForm(request.POST or None)
    if request.method=="POST" and form.is_valid():
        user=form.save(); login(request,user); messages.success(request,"Registration successful."); return redirect("dashboard")
    return render(request,"form.html",{"form":form,"title":"Create Customer Account","button":"Register"})
def _role_login(request, role, template, redirect_name):
    if request.user.is_authenticated: return redirect("dashboard")
    if request.method=="POST":
        user=authenticate(request,username=request.POST.get("username","").strip(),password=request.POST.get("password",""))
        if user and user.role==role: login(request,user); return redirect(redirect_name)
        messages.error(request,"Invalid username/password or wrong account type.")
    return render(request,template)
def login_view(request): return _role_login(request,User.Roles.CUSTOMER,"login.html","dashboard")
def courier_login(request): return _role_login(request,User.Roles.COURIER,"courier/login.html","dashboard")
def admin_login(request): return _role_login(request,User.Roles.ADMIN,"admin/login.html","dashboard")
@login_required
def logout_view(request): logout(request); return redirect("home")

@login_required
def dashboard(request):
    if request.user.role==User.Roles.ADMIN or request.user.is_superuser:
        all_orders = Order.objects.all()
        status_counts = {key: all_orders.filter(status=key).count() for key, _ in Order.Status.choices}
        payment_counts = {key: Payment.objects.filter(payment_method=key).count() for key, _ in Payment.Methods.choices}
        payment_stats = [(label, payment_counts.get(key, 0)) for key, label in Payment.Methods.choices]
        total_revenue = all_orders.aggregate(v=Sum("total_amount"))["v"] or Decimal("0.00")
        paid_revenue = Payment.objects.filter(payment_status=Payment.Status.PAID).aggregate(v=Sum("amount"))["v"] or Decimal("0.00")
        recent_orders = all_orders.select_related("customer").prefetch_related("deliveries__courier").order_by("-order_date")[:8]
        return render(request,"admin/dashboard.html",{
            "customers":Customer.objects.count(), "couriers":Courier.objects.count(),
            "orders":all_orders.count(), "deliveries":Delivery.objects.count(), "payments":Payment.objects.count(),
            "pending_orders":status_counts.get(Order.Status.PENDING,0), "delivered":status_counts.get(Order.Status.DELIVERED,0),
            "status_counts":status_counts, "status_choices":Order.Status.choices,
            "payment_counts":payment_counts, "payment_choices":Payment.Methods.choices, "payment_stats":payment_stats,
            "total_revenue":total_revenue, "paid_revenue":paid_revenue, "recent_orders":recent_orders,
        })
    if request.user.role==User.Roles.COURIER:
        courier=get_object_or_404(Courier,user=request.user); deliveries=Delivery.objects.filter(courier=courier).select_related("order","order__customer"); return render(request,"courier/dashboard.html",{"courier":courier,"deliveries":deliveries})
    customer=get_object_or_404(Customer,user=request.user); orders=customer.orders.prefetch_related("items","deliveries").all(); return render(request,"customer/dashboard.html",{"customer":customer,"orders":orders[:8],"delivered_count":customer.orders.filter(status=Order.Status.DELIVERED).count()})

@role_required(User.Roles.CUSTOMER)
def profile(request):
    customer=get_object_or_404(Customer,user=request.user); form=ProfileForm(request.POST or None,instance=customer)
    if request.method=="POST" and form.is_valid(): form.save(); messages.success(request,"Profile updated."); return redirect("profile")
    return render(request,"form.html",{"form":form,"title":"Manage Profile","button":"Save Changes"})
@role_required(User.Roles.CUSTOMER)
def parcel_list(request): return render(request,"customer/parcels.html",{"parcels":Parcel.objects.filter(is_service=True).select_related("category")})

def track_parcel(request):
    tracking_number = request.GET.get("tracking_number", "").strip().upper()
    order = None
    if tracking_number:
        order = Order.objects.filter(tracking_number=tracking_number).prefetch_related("items__parcel", "deliveries__tracking_updates", "deliveries__courier").first()
        if not order:
            messages.error(request, "No parcel was found for that tracking number.")
    return render(request, "track_parcel.html", {"tracking_number": tracking_number, "order": order})

def _expected_date(delivery_type):
    days={Order.DeliveryTypes.STANDARD:3,Order.DeliveryTypes.EXPRESS:2,Order.DeliveryTypes.EMERGENCY:1}; return timezone.localdate()+timedelta(days=days.get(delivery_type,3))
def _calculate_zone(pickup_division, pickup_district, pickup_area, delivery_division, delivery_district, delivery_area):
    if pickup_division == delivery_division and pickup_district == delivery_district and pickup_area.strip().lower() == delivery_area.strip().lower():
        return Order.Zones.SAME_AREA
    if pickup_division == delivery_division and pickup_district == delivery_district:
        return Order.Zones.SAME_CITY
    # Remote-area classification is based on district names commonly treated as remote/service areas.
    remote = {"Bandarban", "Rangamati", "Khagrachhari", "Cox's Bazar", "Sunamganj", "Bhola", "Barguna", "Patuakhali", "Pirojpur", "Kurigram", "Panchagarh", "Thakurgaon", "Nilphamari"}
    if delivery_district in remote or pickup_district in remote:
        return Order.Zones.REMOTE
    return Order.Zones.OUTSIDE_CITY

@role_required(User.Roles.CUSTOMER)
def create_order(request):
    customer=get_object_or_404(Customer,user=request.user)
    form=OrderForm(request.POST or None)
    if request.method=="POST" and form.is_valid():
        d=form.cleaned_data; parcel=d["parcel"]; qty=d["quantity"]; weight=form.get_weight_kg() * qty
        if parcel.emergency_delivery and d["delivery_type"]!=Order.DeliveryTypes.EMERGENCY:
            form.add_error("delivery_type", "This parcel requires Emergency delivery.")
        if form.errors:
            return render(request,"customer/create_order.html",{"form":form,"divisions":BANGLADESH_DIVISIONS,"divisions_json":json.dumps(BANGLADESH_DIVISIONS)})
        zone=_calculate_zone(d["pickup_division"],d["pickup_district"],d["pickup_area"],d["delivery_division"],d["delivery_district"],d["delivery_area"])
        charge=PricingRule.calculate(weight,zone,d["delivery_type"],parcel.fragile or parcel.special_handling)
        total=charge
        with transaction.atomic():
            order=Order.objects.create(customer=customer,sender_name=d["sender_name"],sender_phone=d["sender_phone"],sender_email=d["sender_email"],pickup_country="Bangladesh",pickup_division=d["pickup_division"],pickup_district=d["pickup_district"],pickup_area=d["pickup_area"],pickup_postal_code=d["pickup_postal_code"],pickup_address=d["pickup_address"],receiver_name=d["receiver_name"],receiver_phone=d["receiver_phone"],delivery_country="Bangladesh",delivery_division=d["delivery_division"],delivery_district=d["delivery_district"],delivery_area=d["delivery_area"],delivery_postal_code=d["delivery_postal_code"],delivery_address=d["delivery_address"],delivery_type=d["delivery_type"],zone=zone,expected_delivery_date=_expected_date(d["delivery_type"]),total_weight=weight,delivery_charge=charge,total_amount=total)
            OrderItem.objects.create(order=order,parcel=parcel,quantity=qty,price=parcel.base_price)
            Payment.objects.create(order=order,amount=total,payment_by=d["payment_by"],payment_method=d["payment_method"],payment_status=Payment.Status.PENDING)
        messages.success(request,f"Order {order} created. Delivery charge BDT {charge}.")
        return redirect("order_detail",order_id=order.order_id)
    return render(request,"customer/create_order.html",{"form":form,"divisions":BANGLADESH_DIVISIONS,"divisions_json":json.dumps(BANGLADESH_DIVISIONS)})

@role_required(User.Roles.CUSTOMER)
def cancel_order(request,order_id):
    customer=get_object_or_404(Customer,user=request.user); order=get_object_or_404(Order,order_id=order_id,customer=customer)
    if request.method=="POST" and order.can_cancel:
        order.status=Order.Status.CANCELLED; order.cancellation_reason=request.POST.get("reason","").strip() or "Cancelled by customer"; order.save(); messages.success(request,"Order cancelled successfully.")
    return redirect("order_detail",order_id=order.order_id)

def customer_orders(request):
    customer=get_object_or_404(Customer,user=request.user); return render(request,"customer/orders.html",{"orders":customer.orders.prefetch_related("items","deliveries").all()})
@login_required
def order_detail(request,order_id):
    order=get_object_or_404(Order.objects.prefetch_related("items","deliveries__tracking_updates","deliveries__courier"),order_id=order_id)
    if request.user.role==User.Roles.CUSTOMER and order.customer.user!=request.user: messages.error(request,"You cannot access this order."); return redirect("dashboard")
    return render(request,"order_detail.html",{"order":order})
@role_required(User.Roles.CUSTOMER)
def make_payment(request,order_id):
    customer=get_object_or_404(Customer,user=request.user)
    order=get_object_or_404(Order,order_id=order_id,customer=customer)
    payment=get_object_or_404(Payment,order=order)
    form=PaymentForm(request.POST or None,instance=payment)
    item=order.items.select_related("parcel","parcel__category").first()
    if request.method=="POST" and form.is_valid():
        p=form.save(commit=False)
        p.amount=order.total_amount
        if p.payment_method==Payment.Methods.CASH:
            # COD/cash is collected physically by the courier; it becomes paid after collection/delivery.
            p.payment_status=Payment.Status.PENDING
            p.paid_at=None
            message="Cash on Delivery selected. Payment will be collected when the parcel is delivered."
        else:
            # This project simulates successful online payment; a real gateway can be connected later.
            p.payment_status=Payment.Status.PAID
            p.paid_at=timezone.now()
            message="Payment details saved and payment marked as paid for this demo."
        p.save()
        messages.success(request,message)
        return redirect("order_detail",order_id=order.order_id)
    context={
        "form":form,
        "title":f"Payment for ORD-{order.order_id:05d}",
        "button":"Continue to Confirmation",
        "order":order,
        "payment":payment,
        "item":item,
        "mobile_providers":["bKash","Nagad","Rocket","Upay","Tap","mCash","SureCash"],
        "banks":[
            "Sonali Bank PLC","Janata Bank PLC","Agrani Bank PLC","Rupali Bank PLC",
            "Dutch-Bangla Bank PLC","BRAC Bank PLC","The City Bank PLC","Eastern Bank PLC",
            "Prime Bank PLC","Bank Asia PLC","Islami Bank Bangladesh PLC","United Commercial Bank PLC",
            "Pubali Bank PLC","IFIC Bank PLC","Southeast Bank PLC","NCC Bank PLC",
            "Mutual Trust Bank PLC","Dhaka Bank PLC","Trust Bank PLC","Standard Chartered Bangladesh",
            "HSBC Bangladesh"
        ],
    }
    return render(request,"customer/payment.html",context)
@role_required(User.Roles.COURIER)
def courier_update_delivery(request,delivery_id):
    courier=get_object_or_404(Courier,user=request.user); delivery=get_object_or_404(Delivery,delivery_id=delivery_id,courier=courier)
    if request.method=="POST":
        status=request.POST.get("status",Delivery.Status.IN_TRANSIT); location=request.POST.get("location","").strip() or courier.current_area or "Updated by courier"; note=request.POST.get("note","").strip(); failed=request.POST.get("failed_reason",""); receiver=request.POST.get("receiver_confirmation","").strip()
        delivery.status=status
        if status==Delivery.Status.PICKED_UP: delivery.pickup_date=timezone.now()
        if status==Delivery.Status.DELIVERED:
            delivery.delivery_date=timezone.now()
            delivery.delivered_by=courier.name
            delivery.receiver_confirmation=receiver
        if status==Delivery.Status.FAILED: delivery.failed_reason=failed; delivery.return_to_sender=request.POST.get("return_to_sender")=="on"
        delivery.save()
        # Recalculate availability from all active assignments. This prevents a courier
        # with another active delivery from becoming AVAILABLE too early.
        _sync_courier_status(courier)
        mapping={Delivery.Status.ASSIGNED:Order.Status.ASSIGNED,Delivery.Status.PICKUP_SCHEDULED:Order.Status.PICKUP_SCHEDULED,Delivery.Status.PICKED_UP:Order.Status.PICKED_UP,Delivery.Status.SORTING:Order.Status.SORTING,Delivery.Status.IN_TRANSIT:Order.Status.IN_TRANSIT,Delivery.Status.OUT_FOR_DELIVERY:Order.Status.OUT_FOR_DELIVERY,Delivery.Status.DELIVERED:Order.Status.DELIVERED,Delivery.Status.FAILED:Order.Status.FAILED,Delivery.Status.RETURNED:Order.Status.RETURNED,Delivery.Status.CANCELLED:Order.Status.CANCELLED}
        order=delivery.order; order.status=mapping.get(status,order.status); order.failed_reason=delivery.get_failed_reason_display() if status==Delivery.Status.FAILED else order.failed_reason; order.return_to_sender=delivery.return_to_sender; order.save()
        Tracking.objects.create(delivery=delivery,location=location,status=delivery.get_status_display(),note=note)
        if status==Delivery.Status.DELIVERED and order.payment.payment_by==Payment.Payers.RECEIVER: order.payment.payment_status=Payment.Status.PAID; order.payment.paid_at=timezone.now(); order.payment.save()
        messages.success(request,"Delivery status updated."); return redirect("dashboard")
    return render(request,"courier/update_delivery.html",{"delivery":delivery,"statuses":Delivery.Status.choices,"failed_reasons":Delivery.FailedReasons.choices})

@role_required(User.Roles.ADMIN)
def admin_customers(request): return render(request,"admin/customers.html",{"customers":Customer.objects.select_related("user").all()})
def _sync_courier_status(courier):
    if courier.status == Courier.Status.INACTIVE:
        return
    active_delivery_statuses = [
        Delivery.Status.ASSIGNED, Delivery.Status.PICKUP_SCHEDULED, Delivery.Status.PICKED_UP,
        Delivery.Status.SORTING, Delivery.Status.IN_TRANSIT, Delivery.Status.OUT_FOR_DELIVERY,
    ]
    has_active = Delivery.objects.filter(courier=courier, status__in=active_delivery_statuses).exists()
    courier.status = Courier.Status.BUSY if has_active else Courier.Status.AVAILABLE
    courier.save(update_fields=["status"])

@role_required(User.Roles.ADMIN)
def admin_couriers(request):
    couriers=Courier.objects.select_related("user").prefetch_related("deliveries").all()
    search=request.GET.get("q","").strip()
    status=request.GET.get("status","").strip()
    if search:
        from django.db.models import Q
        couriers=couriers.filter(Q(name__icontains=search)|Q(phone__icontains=search)|Q(email__icontains=search)|Q(vehicle_no__icontains=search)|Q(license_no__icontains=search)|Q(current_area__icontains=search)|Q(user__username__icontains=search))
    if status:
        couriers=couriers.filter(status=status)
    form=CourierCreateForm(request.POST or None)
    if request.method=="POST" and form.is_valid():
        d=form.cleaned_data; username=d["name"].lower().replace(" ","")[:20] or "courier"; base=username; i=1
        while User.objects.filter(username=username).exists(): i+=1; username=f"{base}{i}"
        import secrets,string; password="".join(secrets.choice(string.ascii_letters+string.digits) for _ in range(10)); u=User.objects.create_user(username=username,email=d["email"],password=password,role=User.Roles.COURIER); Courier.objects.create(user=u,**d); messages.success(request,f"Courier created. Username: {username} | Temporary password: {password}"); return redirect("admin_couriers")
    return render(request,"admin/couriers.html",{"couriers":couriers,"form":form,"search":search,"status_filter":status,"status_choices":Courier.Status.choices,"total_couriers":Courier.objects.count(),"available_couriers":Courier.objects.filter(status=Courier.Status.AVAILABLE).count(),"busy_couriers":Courier.objects.filter(status=Courier.Status.BUSY).count(),"inactive_couriers":Courier.objects.filter(status=Courier.Status.INACTIVE).count()})

@role_required(User.Roles.ADMIN)
def edit_courier(request,courier_id):
    courier=get_object_or_404(Courier.objects.select_related("user"),courier_id=courier_id)
    form=CourierUpdateForm(request.POST or None,instance=courier)
    if request.method=="POST" and form.is_valid():
        obj=form.save()
        obj.user.email=obj.email
        obj.user.save(update_fields=["email"])
        messages.success(request,"Courier information updated successfully.")
        return redirect("admin_couriers")
    return render(request,"admin/edit_courier.html",{"form":form,"courier":courier})
@role_required(User.Roles.ADMIN)
def admin_categories(request):
    form=CategoryForm(request.POST or None); categories=Category.objects.all()
    if request.method=="POST" and form.is_valid(): form.save(); messages.success(request,"Category created."); return redirect("admin_categories")
    return render(request,"admin/categories.html",{"categories":categories,"form":form})
@role_required(User.Roles.ADMIN)
def admin_parcels(request):
    # This page is intentionally focused on creating a parcel service and
    # sending it as an order. The old GET search/filter UI has been removed.
    form = AdminSendParcelForm(request.POST or None)

    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            parcel = form.save()

            # An Order requires a Customer FK. Admin/Sender can still create
            # the shipment from this screen, so use the admin user's customer
            # profile as the sender/customer record. Create that profile once
            # if this admin account does not already have one.
            customer, _ = Customer.objects.get_or_create(
                user=request.user,
                defaults={
                    "name": request.user.get_full_name() or request.user.username,
                    "phone": "",
                    "address": "",
                },
            )

            quantity = parcel.quantity or 1
            weight = parcel.weight * quantity
            delivery_type = (
                Order.DeliveryTypes.EMERGENCY
                if parcel.emergency_delivery
                else Order.DeliveryTypes.STANDARD
            )

            # The admin parcel form does not ask for pickup/delivery zone, so
            # use the standard same-city default. The receiver address is
            # copied from the parcel into the order.
            zone = Order.Zones.SAME_CITY
            charge = PricingRule.calculate(
                weight,
                zone,
                delivery_type,
                parcel.fragile or parcel.special_handling,
            )

            sender_name = customer.name or request.user.get_full_name() or request.user.username
            sender_phone = customer.phone or ""
            sender_email = request.user.email or ""

            order = Order.objects.create(
                customer=customer,
                sender_name=sender_name,
                sender_phone=sender_phone,
                sender_email=sender_email,
                pickup_country="Bangladesh",
                pickup_division="Dhaka",
                pickup_district="Dhaka",
                pickup_area="",
                pickup_postal_code="",
                pickup_address=customer.address or "Admin/Sender pickup address",
                receiver_name=parcel.receiver_name,
                receiver_phone=parcel.receiver_phone,
                delivery_country="Bangladesh",
                delivery_division=parcel.destination_division or "Dhaka",
                delivery_district=parcel.destination_district or "Dhaka",
                delivery_area=parcel.destination_area or "",
                delivery_postal_code="",
                delivery_address=parcel.receiver_address,
                delivery_type=delivery_type,
                zone=zone,
                expected_delivery_date=_expected_date(delivery_type),
                total_weight=weight,
                delivery_charge=charge,
                total_amount=charge,
            )

            OrderItem.objects.create(
                order=order,
                parcel=parcel,
                quantity=quantity,
                price=parcel.base_price or Decimal("0.00"),
            )

            Payment.objects.create(
                order=order,
                amount=order.total_amount,
                payment_by=form.cleaned_data["payment_by"],
                payment_method=form.cleaned_data["payment_method"],
                payment_status=Payment.Status.PENDING,
                payment_provider=form.cleaned_data.get("payment_provider", ""),
                account_name=form.cleaned_data.get("account_name", ""),
                account_number=form.cleaned_data.get("account_number", ""),
                bank_name=form.cleaned_data.get("bank_name", ""),
                branch_name=form.cleaned_data.get("branch_name", ""),
                routing_number=form.cleaned_data.get("routing_number", ""),
                payment_note=form.cleaned_data.get("payment_note", ""),
            )

        messages.success(
            request,
            f"Order ORD-{order.order_id:05d} created successfully and added to Manage Orders."
        )
        return redirect("admin_orders")

    parcels = Parcel.objects.filter(is_service=True).select_related("category")
    return render(
        request,
        "admin/parcels.html",
        {"parcels": parcels, "form": form},
    )

@role_required(User.Roles.ADMIN)
def edit_parcel(request, parcel_id):
    parcel=get_object_or_404(Parcel, parcel_id=parcel_id)
    form=ParcelForm(request.POST or None, instance=parcel)
    if request.method=="POST" and form.is_valid():
        form.save(); messages.success(request,"Parcel/service updated successfully."); return redirect("admin_parcels")
    return render(request,"admin/edit_parcel.html",{"form":form,"parcel":parcel})

@role_required(User.Roles.ADMIN)
def archive_parcel(request, parcel_id):
    parcel=get_object_or_404(Parcel, parcel_id=parcel_id)
    if request.method=="POST":
        parcel.is_service=False; parcel.save(update_fields=["is_service"]); messages.success(request,"Parcel service archived.")
    return redirect("admin_parcels")
@role_required(User.Roles.ADMIN)
def admin_orders(request):
    qs = Order.objects.select_related("customer").prefetch_related("deliveries__courier", "payment").all()
    search = request.GET.get("q", "").strip()
    status = request.GET.get("status", "").strip()
    payment_method = request.GET.get("payment_method", "").strip()
    delivery_type = request.GET.get("delivery_type", "").strip()
    date_from = request.GET.get("date_from", "").strip()
    date_to = request.GET.get("date_to", "").strip()

    if search:
        from django.db.models import Q
        search_q = (
            Q(tracking_number__icontains=search) |
            Q(receiver_name__icontains=search) |
            Q(receiver_phone__icontains=search) |
            Q(sender_name__icontains=search) |
            Q(sender_phone__icontains=search) |
            Q(customer__name__icontains=search) |
            Q(customer__user__username__icontains=search)
        )
        # The UI displays order IDs as ORD-00001, while the database stores
        # the numeric primary key. Support both forms in the search box.
        normalized_order_id = search.upper().strip()
        if normalized_order_id.startswith("ORD-"):
            normalized_order_id = normalized_order_id[4:]
        if normalized_order_id.isdigit():
            search_q |= Q(order_id=int(normalized_order_id))
        qs = qs.filter(search_q)
    if status:
        qs = qs.filter(status=status)
    if payment_method:
        qs = qs.filter(payment__payment_method=payment_method)
    if delivery_type:
        qs = qs.filter(delivery_type=delivery_type)
    if date_from:
        qs = qs.filter(order_date__date__gte=date_from)
    if date_to:
        qs = qs.filter(order_date__date__lte=date_to)

    all_orders = Order.objects.all()
    status_counts = {key: all_orders.filter(status=key).count() for key, _ in Order.Status.choices}
    payment_counts = {key: Payment.objects.filter(payment_method=key).count() for key, _ in Payment.Methods.choices}
    total_revenue = all_orders.aggregate(v=Sum("total_amount"))["v"] or Decimal("0.00")
    paid_revenue = Payment.objects.filter(payment_status=Payment.Status.PAID).aggregate(v=Sum("amount"))["v"] or Decimal("0.00")
    context = {
        "orders": qs,
        "search": search, "status_filter": status, "payment_filter": payment_method,
        "delivery_filter": delivery_type, "date_from": date_from, "date_to": date_to,
        "status_choices": Order.Status.choices,
        "payment_choices": Payment.Methods.choices,
        "delivery_choices": Order.DeliveryTypes.choices,
        "status_counts": status_counts,
        "payment_counts": payment_counts,
        "total_revenue": total_revenue, "paid_revenue": paid_revenue,
        "filtered_count": qs.count(),
        "total_orders": Order.objects.count(),
    }
    return render(request, "admin/orders.html", context)
@role_required(User.Roles.ADMIN)
def assign_courier(request,order_id):
    order=get_object_or_404(Order,order_id=order_id); delivery=order.deliveries.first()
    couriers=Courier.objects.filter(status__in=[Courier.Status.AVAILABLE,Courier.Status.BUSY]).order_by("status","name")
    if request.method=="POST":
        courier=get_object_or_404(Courier,courier_id=request.POST.get("courier_id"),status__in=[Courier.Status.AVAILABLE,Courier.Status.BUSY])
        old_courier=delivery.courier if delivery else None
        if not delivery:
            delivery=Delivery.objects.create(order=order,courier=courier,expected_delivery_date=order.expected_delivery_date,delivery_charges=order.delivery_charge)
        else:
            delivery.courier=courier; delivery.status=Delivery.Status.ASSIGNED; delivery.save()
        order.status=Order.Status.ASSIGNED; order.save()
        _sync_courier_status(courier)
        if courier.status != Courier.Status.INACTIVE:
            courier.status=Courier.Status.BUSY; courier.save(update_fields=["status"])
        if old_courier and old_courier.courier_id != courier.courier_id:
            _sync_courier_status(old_courier)
        Tracking.objects.create(delivery=delivery,location=courier.current_area or "Courier assigned",status="Courier Assigned",note="Order assigned by admin.")
        messages.success(request,f"Courier {courier.name} assigned successfully."); return redirect("admin_orders")
    return render(request,"admin/assign_courier.html",{"order":order,"couriers":couriers,"current_courier":delivery.courier if delivery else None})
@role_required(User.Roles.ADMIN)
def pricing_rules(request):
    form=PricingRuleForm(request.POST or None)
    rules=PricingRule.objects.all().order_by("zone", "delivery_type", "min_weight", "name")
    search=request.GET.get("q", "").strip()
    zone=request.GET.get("zone", "").strip()
    delivery_type=request.GET.get("delivery_type", "").strip()
    active=request.GET.get("active", "").strip()
    if search:
        rules=rules.filter(name__icontains=search)
    if zone:
        rules=rules.filter(zone=zone)
    if delivery_type:
        rules=rules.filter(delivery_type=delivery_type)
    if active in {"0", "1"}:
        rules=rules.filter(active=(active == "1"))
    if request.method=="POST" and form.is_valid():
        obj=form.save(commit=False)
        if obj.min_weight > obj.max_weight:
            form.add_error("max_weight", "Maximum weight must be greater than or equal to minimum weight.")
        else:
            obj.save(); messages.success(request,"Pricing rule saved successfully."); return redirect("pricing_rules")
    return render(request,"admin/pricing_rules.html",{"form":form,"rules":rules,"search":search,"zone_filter":zone,"delivery_filter":delivery_type,"active_filter":active,"zone_choices":PricingRule.Zones.choices,"delivery_type_choices":PricingRule.DeliveryTypes.choices})

@role_required(User.Roles.ADMIN)
def edit_pricing_rule(request, rule_id):
    rule=get_object_or_404(PricingRule, id=rule_id)
    form=PricingRuleForm(request.POST or None, instance=rule)
    if request.method=="POST" and form.is_valid():
        obj=form.save(commit=False)
        if obj.min_weight > obj.max_weight:
            form.add_error("max_weight", "Maximum weight must be greater than or equal to minimum weight.")
        else:
            obj.save(); messages.success(request,"Pricing rule updated successfully."); return redirect("pricing_rules")
    return render(request,"admin/edit_pricing_rule.html",{"form":form,"rule":rule})

@role_required(User.Roles.ADMIN)
def toggle_pricing_rule(request, rule_id):
    rule=get_object_or_404(PricingRule, id=rule_id)
    if request.method=="POST":
        rule.active=not rule.active; rule.save(update_fields=["active"]); messages.success(request, f"Pricing rule {'activated' if rule.active else 'deactivated'}.")
    return redirect("pricing_rules")

@role_required(User.Roles.CUSTOMER)
def price_preview(request):
    try:
        parcel_id=request.GET.get("parcel_id")
        quantity=max(1, int(request.GET.get("quantity", "1")))
        weight=Decimal(request.GET.get("weight", "1"))
        delivery_type=request.GET.get("delivery_type", Order.DeliveryTypes.STANDARD)
        pickup_division=request.GET.get("pickup_division", "")
        pickup_district=request.GET.get("pickup_district", "")
        pickup_area=request.GET.get("pickup_area", "")
        delivery_division=request.GET.get("delivery_division", "")
        delivery_district=request.GET.get("delivery_district", "")
        delivery_area=request.GET.get("delivery_area", "")
        if delivery_type not in dict(Order.DeliveryTypes.choices):
            return JsonResponse({"ok":False,"error":"Invalid delivery type."}, status=400)
        if not parcel_id or not pickup_division or not pickup_district or not delivery_division or not delivery_district:
            return JsonResponse({"ok":False,"message":"Select parcel, pickup and delivery locations to preview the charge."})
        parcel=get_object_or_404(Parcel, parcel_id=parcel_id, is_service=True)
        zone=_calculate_zone(pickup_division,pickup_district,pickup_area,delivery_division,delivery_district,delivery_area)
        charge=PricingRule.calculate(weight*quantity,zone,delivery_type,parcel.fragile or parcel.special_handling)
        return JsonResponse({"ok":True,"zone":zone,"zone_label":dict(Order.Zones.choices).get(zone,zone),"delivery_charge":f"{charge:.2f}","total_amount":f"{charge:.2f}","currency":"BDT"})
    except (ValueError, TypeError, ArithmeticError):
        return JsonResponse({"ok":False,"error":"Please enter a valid weight and quantity."}, status=400)
@role_required(User.Roles.ADMIN)
def reports(request):
    month=request.GET.get("month") or timezone.localdate().strftime("%Y-%m"); qs=Order.objects.all()
    try: year,mon=map(int,month.split("-")); qs=qs.filter(order_date__year=year,order_date__month=mon)
    except: month=timezone.localdate().strftime("%Y-%m")
    context={"month":month,"orders":qs.count(),"delivered":qs.filter(status=Order.Status.DELIVERED).count(),"cancelled":qs.filter(status=Order.Status.CANCELLED).count(),"failed":qs.filter(status=Order.Status.FAILED).count(),"pending":qs.filter(status__in=[Order.Status.PENDING,Order.Status.CONFIRMED]).count(),"parcels":OrderItem.objects.filter(order__in=qs).aggregate(v=Sum("quantity"))["v"] or 0,"weight":qs.aggregate(v=Sum("total_weight"))["v"] or 0,"fragile":OrderItem.objects.filter(order__in=qs,parcel__fragile=True).count(),"emergency":qs.filter(delivery_type=Order.DeliveryTypes.EMERGENCY).count(),"express":qs.filter(delivery_type=Order.DeliveryTypes.EXPRESS).count(),"standard":qs.filter(delivery_type=Order.DeliveryTypes.STANDARD).count(),"charges":qs.aggregate(v=Sum("delivery_charge"))["v"] or Decimal("0.00"),"paid":Payment.objects.filter(order__in=qs,payment_status=Payment.Status.PAID).aggregate(v=Sum("amount"))["v"] or Decimal("0.00"),"assigned":Delivery.objects.filter(order__in=qs).count(),"courier_delivered":Delivery.objects.filter(order__in=qs,status=Delivery.Status.DELIVERED).count(),"courier_failed":Delivery.objects.filter(order__in=qs,status=Delivery.Status.FAILED).count(),"same_area":qs.filter(zone=Order.Zones.SAME_AREA).count(),"same_city":qs.filter(zone=Order.Zones.SAME_CITY).count(),"outside_city":qs.filter(zone=Order.Zones.OUTSIDE_CITY).count(),"remote":qs.filter(zone=Order.Zones.REMOTE).count(),"cash":Payment.objects.filter(order__in=qs,payment_method=Payment.Methods.CASH).count(),"card":Payment.objects.filter(order__in=qs,payment_method=Payment.Methods.CARD).count(),"mobile":Payment.objects.filter(order__in=qs,payment_method=Payment.Methods.MOBILE).count(),"bank_transfer":Payment.objects.filter(order__in=qs,payment_method=Payment.Methods.BANK_TRANSFER).count()}
    return render(request,"admin/reports.html",context)
@role_required(User.Roles.ADMIN)
def export_report_pdf(request):
    try: from reportlab.lib.pagesizes import A4; from reportlab.pdfgen import canvas
    except ImportError: return HttpResponse("ReportLab is not installed. Run: pip install -r requirements.txt",status=500)
    month=request.GET.get("month") or timezone.localdate().strftime("%Y-%m")
    try: year,mon=map(int,month.split("-")); qs=Order.objects.filter(order_date__year=year,order_date__month=mon)
    except: qs=Order.objects.none(); month="Invalid"
    response=HttpResponse(content_type="application/pdf"); response["Content-Disposition"]=f'attachment; filename="courier_report_{month}.pdf"'; pdf=canvas.Canvas(response,pagesize=A4); w,h=A4; y=h-55
    pdf.setFont("Helvetica-Bold",17); pdf.drawString(45,y,"Courier Management System - Monthly Report"); y-=25; pdf.setFont("Helvetica",10); pdf.drawString(45,y,f"Month: {month}"); y-=25
    stats=[("Total Orders",qs.count()),("Delivered",qs.filter(status=Order.Status.DELIVERED).count()),("Cancelled",qs.filter(status=Order.Status.CANCELLED).count()),("Failed",qs.filter(status=Order.Status.FAILED).count()),("Total Parcels",OrderItem.objects.filter(order__in=qs).aggregate(v=Sum("quantity"))["v"] or 0),("Total Weight (KG)",qs.aggregate(v=Sum("total_weight"))["v"] or 0),("Delivery Charges (BDT)",qs.aggregate(v=Sum("delivery_charge"))["v"] or 0),("Paid Revenue (BDT)",Payment.objects.filter(order__in=qs,payment_status=Payment.Status.PAID).aggregate(v=Sum("amount"))["v"] or 0)]
    for label,val in stats: pdf.drawString(55,y,f"{label}: {val}"); y-=19
    y-=10; pdf.setFont("Helvetica-Bold",11); pdf.drawString(45,y,"Courier Performance"); y-=20; pdf.setFont("Helvetica",9)
    for c in Courier.objects.all():
        a=Delivery.objects.filter(order__in=qs,courier=c).count(); d=Delivery.objects.filter(order__in=qs,courier=c,status=Delivery.Status.DELIVERED).count(); f=Delivery.objects.filter(order__in=qs,courier=c,status=Delivery.Status.FAILED).count(); pdf.drawString(55,y,f"{c.name[:25]} | Assigned: {a} | Delivered: {d} | Failed: {f}"); y-=16
        if y<55: pdf.showPage(); y=h-55; pdf.setFont("Helvetica",9)
    pdf.save(); return response

