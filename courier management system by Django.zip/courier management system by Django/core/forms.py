from decimal import Decimal
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.db import transaction
from .models import User, Customer, Category, Parcel, Order, Payment, Tracking, Courier, PricingRule
from .bangladesh import BANGLADESH_DIVISIONS, WEIGHT_RANGES

class RegisterForm(UserCreationForm):
    email=forms.EmailField(); name=forms.CharField(max_length=120); phone=forms.CharField(max_length=30); address=forms.CharField(widget=forms.Textarea(attrs={"rows":3}))
    class Meta: model=User; fields=("username","email","password1","password2")
    def clean_email(self):
        email=self.cleaned_data["email"].lower()
        if User.objects.filter(email=email).exists(): raise forms.ValidationError("This email is already registered.")
        return email
    @transaction.atomic
    def save(self, commit=True):
        user=super().save(commit=False); user.email=self.cleaned_data["email"]; user.role=User.Roles.CUSTOMER
        if commit: user.save(); Customer.objects.create(user=user,name=self.cleaned_data["name"],phone=self.cleaned_data["phone"],address=self.cleaned_data["address"])
        return user

class ProfileForm(forms.ModelForm):
    class Meta: model=Customer; fields=("name","phone","address"); widgets={"address":forms.Textarea(attrs={"rows":3})}
class CategoryForm(forms.ModelForm):
    class Meta: model=Category; fields=("category_name","description"); widgets={"description":forms.Textarea(attrs={"rows":3})}
class ParcelForm(forms.ModelForm):
    receiver_name = forms.CharField(max_length=120, label="Receiver Name")
    receiver_phone = forms.CharField(max_length=30, label="Receiver Phone")
    receiver_email = forms.EmailField(label="Receiver Email", required=False)
    receiver_address = forms.CharField(
        label="Receiver Address",
        widget=forms.Textarea(attrs={"rows": 2}),
    )
    weight = forms.DecimalField(
        max_digits=8, decimal_places=2, min_value=Decimal("0.01"),
        label="Parcel Weight (KG)"
    )
    quantity = forms.IntegerField(min_value=1, initial=1, label="Parcel Quantity")

    class Meta:
        model = Parcel
        fields = (
            "category", "receiver_name", "receiver_phone", "receiver_email",
            "receiver_address", "weight", "quantity", "fragile",
            "emergency_delivery", "special_handling", "description",
            "delivery_instruction",
        )
        widgets = {
            "description": forms.Textarea(attrs={"rows": 2}),
            "delivery_instruction": forms.Textarea(attrs={"rows": 2}),
        }

    def save(self, commit=True):
        obj = super().save(commit=False)
        obj.name = obj.category.category_name
        obj.is_service = True
        if commit:
            obj.save()
        return obj


class AdminSendParcelForm(ParcelForm):
    """Parcel creation form used by Admin -> Manage Parcel Services.

    Includes the complete payment selection/details needed to create the
    Payment record together with the order.
    """
    MOBILE_PROVIDERS = [
        ("BKASH", "bKash"), ("NAGAD", "Nagad"), ("ROCKET", "Rocket"),
        ("UPAY", "Upay"), ("TAP", "Tap"), ("MCASH", "mCash"),
        ("SURECASH", "SureCash"),
    ]
    BANKS = [
        ("SONALI", "Sonali Bank PLC"), ("JANATA", "Janata Bank PLC"),
        ("AGRANI", "Agrani Bank PLC"), ("RUPALI", "Rupali Bank PLC"),
        ("DBBL", "Dutch-Bangla Bank PLC"), ("BRAC", "BRAC Bank PLC"),
        ("CITY", "The City Bank PLC"), ("EBL", "Eastern Bank PLC"),
        ("PRIME", "Prime Bank PLC"), ("BANK_ASIA", "Bank Asia PLC"),
        ("IBBL", "Islami Bank Bangladesh PLC"), ("UCB", "United Commercial Bank PLC"),
        ("PUBALI", "Pubali Bank PLC"), ("IFIC", "IFIC Bank PLC"),
        ("SOUTHEAST", "Southeast Bank PLC"), ("NCC", "NCC Bank PLC"),
        ("MTB", "Mutual Trust Bank PLC"), ("DHAKA", "Dhaka Bank PLC"),
        ("TRUST", "Trust Bank PLC"), ("SCB", "Standard Chartered Bangladesh"),
        ("HSBC", "HSBC Bangladesh"), ("ONE", "ONE Bank PLC"),
        ("NRBC", "NRBC Bank PLC"), ("PREMIER", "Premier Bank PLC"),
        ("EXIM", "EXIM Bank PLC"), ("AL_ARAFah", "Al-Arafah Islami Bank PLC"),
        ("SHAHJALAL", "Shahjalal Islami Bank PLC"), ("NATIONAL", "National Bank PLC"),
        ("JAMUNA", "Jamuna Bank PLC"), ("MEGHNA", "Meghna Bank PLC"),
    ]

    payment_by = forms.ChoiceField(
        choices=Payment.Payers.choices,
        label="Payment By",
        initial=Payment.Payers.RECEIVER,
        widget=forms.RadioSelect,
    )
    payment_method = forms.ChoiceField(
        choices=Payment.Methods.choices,
        label="Payment Method",
        initial=Payment.Methods.CASH,
        widget=forms.RadioSelect,
    )
    payment_provider = forms.ChoiceField(
        choices=[("", "Select mobile banking")]+MOBILE_PROVIDERS,
        required=False, label="Mobile Banking Provider",
    )
    account_name = forms.CharField(max_length=120, required=False, label="Account Holder Name")
    account_number = forms.CharField(max_length=60, required=False, label="Account / Wallet Number")
    bank_name = forms.ChoiceField(
        choices=[("", "Select bank")]+BANKS,
        required=False, label="Bank",
    )
    branch_name = forms.CharField(max_length=120, required=False, label="Branch Name")
    routing_number = forms.CharField(max_length=30, required=False, label="Routing Number")
    transaction_id = forms.CharField(
        max_length=100, required=False, label="Transaction / Reference ID",
        widget=forms.TextInput(attrs={"placeholder": "Enter transaction/reference ID"}),
    )
    payment_note = forms.CharField(
        required=False, label="Payment Note",
        widget=forms.Textarea(attrs={"rows": 2, "placeholder": "Optional payment note"}),
    )

    def clean(self):
        cleaned = super().clean()
        method = cleaned.get("payment_method")
        provider = (cleaned.get("payment_provider") or "").strip()
        account = (cleaned.get("account_number") or "").strip()
        bank = (cleaned.get("bank_name") or "").strip()
        account_name = (cleaned.get("account_name") or "").strip()
        if method == Payment.Methods.MOBILE:
            if not provider:
                self.add_error("payment_provider", "Please select a mobile banking provider.")
            if not account:
                self.add_error("account_number", "Please enter the mobile wallet number.")
        elif method == Payment.Methods.BANK_TRANSFER:
            if not bank:
                self.add_error("bank_name", "Please select your bank.")
            if not account:
                self.add_error("account_number", "Please enter your bank account number.")
            if not account_name:
                self.add_error("account_name", "Please enter the account holder name.")
        elif method == Payment.Methods.CARD:
            if not account_name:
                self.add_error("account_name", "Please enter the cardholder name.")
        if cleaned.get("transaction_id"):
            ref = cleaned["transaction_id"].strip()
            note = (cleaned.get("payment_note") or "").strip()
            cleaned["payment_note"] = f"Transaction/Reference ID: {ref}" + (f"\n{note}" if note else "")
        return cleaned

class OrderForm(forms.Form):
    parcel = forms.ModelChoiceField(queryset=Parcel.objects.filter(is_service=True), label="Parcel / Item Type")
    quantity = forms.IntegerField(
        min_value=1,
        initial=1,
        label="Parcel Quantity",
        widget=forms.NumberInput(attrs={"min": "1", "step": "1", "inputmode": "numeric"}),
    )
    weight_range = forms.ChoiceField(choices=[(v, l) for v, l, _ in WEIGHT_RANGES], label="Parcel Weight")
    sender_name = forms.CharField(max_length=120)
    sender_phone = forms.CharField(max_length=30)
    sender_email = forms.EmailField(required=False)
    pickup_division = forms.ChoiceField(choices=[(d, d) for d in BANGLADESH_DIVISIONS], label="Pickup Division")
    pickup_district = forms.ChoiceField(choices=[], label="Pickup District")
    pickup_area = forms.CharField(max_length=120)
    pickup_postal_code = forms.CharField(max_length=20)
    pickup_address = forms.CharField(widget=forms.Textarea(attrs={"rows":2}))
    receiver_name = forms.CharField(max_length=120)
    receiver_phone = forms.CharField(max_length=30)
    delivery_division = forms.ChoiceField(choices=[(d, d) for d in BANGLADESH_DIVISIONS], label="Delivery Division")
    delivery_district = forms.ChoiceField(choices=[], label="Delivery District")
    delivery_area = forms.CharField(max_length=120)
    delivery_postal_code = forms.CharField(max_length=20)
    delivery_address = forms.CharField(widget=forms.Textarea(attrs={"rows":2}))
    delivery_type = forms.ChoiceField(choices=Order.DeliveryTypes.choices)
    payment_by = forms.ChoiceField(choices=Payment.Payers.choices)
    payment_method = forms.ChoiceField(choices=Payment.Methods.choices)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Keep the 3-value weight data available to the template for price preview,
        # while the actual ChoiceField uses normal (value, label) choices.
        self.weight_ranges = WEIGHT_RANGES
        self.small_parcel_max_weight = Decimal("5.00")
        self.fields["pickup_district"].choices = [(d, d) for d in BANGLADESH_DIVISIONS["Dhaka"]]
        self.fields["delivery_district"].choices = [(d, d) for d in BANGLADESH_DIVISIONS["Dhaka"]]
        data = self.data if self.is_bound else self.initial
        for div_field, dist_field in (("pickup_division", "pickup_district"), ("delivery_division", "delivery_district")):
            div = data.get(div_field) if data else None
            if div in BANGLADESH_DIVISIONS:
                self.fields[dist_field].choices = [(d, d) for d in BANGLADESH_DIVISIONS[div]]

    def clean(self):
        cleaned = super().clean()
        for div_field, dist_field in (("pickup_division", "pickup_district"), ("delivery_division", "delivery_district")):
            div, district = cleaned.get(div_field), cleaned.get(dist_field)
            if div not in BANGLADESH_DIVISIONS or district not in BANGLADESH_DIVISIONS.get(div, []):
                self.add_error(dist_field, "Please select a valid Bangladesh district for the selected division.")

        parcel = cleaned.get("parcel")
        weight_range = cleaned.get("weight_range")
        if parcel and weight_range:
            selected_weight = next((Decimal(str(weight)) for value, _, weight in WEIGHT_RANGES if value == weight_range), Decimal("1.00"))
            category_name = (parcel.category.category_name if parcel.category_id else "").strip().lower()
            if category_name == "small parcel" and selected_weight > self.small_parcel_max_weight:
                self.add_error("weight_range", "Small Parcel supports a maximum weight of 5 KG. Please select a weight up to 5 KG.")
        return cleaned

    def get_weight_kg(self):
        selected = self.cleaned_data.get("weight_range")
        return next((Decimal(str(weight)) for value, _, weight in WEIGHT_RANGES if value == selected), Decimal("1.00"))

class PaymentForm(forms.ModelForm):
    MOBILE_PROVIDERS = [
        ("BKASH", "bKash"), ("NAGAD", "Nagad"), ("ROCKET", "Rocket"),
        ("UPAY", "Upay"), ("TAP", "Tap"), ("MCASH", "mCash"),
        ("SURECASH", "SureCash"),
    ]
    BANKS = [
        ("SONALI", "Sonali Bank PLC"), ("JANATA", "Janata Bank PLC"),
        ("AGRANI", "Agrani Bank PLC"), ("RUPALI", "Rupali Bank PLC"),
        ("DBBL", "Dutch-Bangla Bank PLC"), ("BRAC", "BRAC Bank PLC"),
        ("CITY", "The City Bank PLC"), ("EBL", "Eastern Bank PLC"),
        ("PRIME", "Prime Bank PLC"), ("BANK_ASIA", "Bank Asia PLC"),
        ("IBBL", "Islami Bank Bangladesh PLC"), ("UCB", "United Commercial Bank PLC"),
        ("PUBALI", "Pubali Bank PLC"), ("IFIC", "IFIC Bank PLC"),
        ("SOUTHEAST", "Southeast Bank PLC"), ("NCC", "NCC Bank PLC"),
        ("MTB", "Mutual Trust Bank PLC"), ("DHAKA", "Dhaka Bank PLC"),
        ("TRUST", "Trust Bank PLC"), ("SCB", "Standard Chartered Bangladesh"),
        ("HSBC", "HSBC Bangladesh"), ("ONE", "ONE Bank PLC"),
        ("NRBC", "NRBC Bank PLC"), ("PREMIER", "Premier Bank PLC"),
        ("EXIM", "EXIM Bank PLC"), ("AL_ARAFah", "Al-Arafah Islami Bank PLC"),
        ("SHAHJALAL", "Shahjalal Islami Bank PLC"), ("NATIONAL", "National Bank PLC"),
        ("JAMUNA", "Jamuna Bank PLC"), ("MEGHNA", "Meghna Bank PLC"),
    ]
    payment_provider = forms.ChoiceField(
        choices=[("", "Select a mobile banking provider")] + MOBILE_PROVIDERS,
        required=False,
        label="Mobile Banking Provider",
    )
    bank_name = forms.ChoiceField(
        choices=[("", "Select your bank")] + BANKS,
        required=False,
        label="Your Bank",
    )

    class Meta:
        model = Payment
        fields = ("payment_by", "payment_method", "payment_provider", "account_name", "account_number", "bank_name", "branch_name", "routing_number", "payment_note")
        widgets = {
            "payment_by": forms.RadioSelect,
            "payment_method": forms.RadioSelect,
            "payment_note": forms.Textarea(attrs={"rows": 3, "placeholder": "Optional note for the payment team"}),
        }
        labels = {
            "payment_provider": "Mobile Banking Provider",
            "account_name": "Account Holder Name",
            "account_number": "Account / Wallet Number",
            "bank_name": "Your Bank",
            "branch_name": "Branch Name",
            "routing_number": "Routing Number (optional)",
            "payment_note": "Payment Note (optional)",
        }

    def clean(self):
        cleaned = super().clean()
        payer = cleaned.get("payment_by")
        method = cleaned.get("payment_method")
        provider = (cleaned.get("payment_provider") or "").strip()
        account = (cleaned.get("account_number") or "").strip()
        bank = (cleaned.get("bank_name") or "").strip()
        account_name = (cleaned.get("account_name") or "").strip()

        if method == Payment.Methods.MOBILE:
            if not provider:
                self.add_error("payment_provider", "Please select a mobile banking provider.")
            if not account:
                self.add_error("account_number", "Please enter the mobile wallet number.")
        elif method == Payment.Methods.BANK_TRANSFER:
            if not bank:
                self.add_error("bank_name", "Please select your bank.")
            if not account:
                self.add_error("account_number", "Please enter your bank account number.")
            if not account_name:
                self.add_error("account_name", "Please enter the account holder name.")
        elif method == Payment.Methods.CARD:
            if not account_name:
                self.add_error("account_name", "Please enter the cardholder name.")
        return cleaned

class TrackingForm(forms.ModelForm):
    class Meta: model=Tracking; fields=("location","status","note"); widgets={"note":forms.Textarea(attrs={"rows":2})}
class PricingRuleForm(forms.ModelForm):
    class Meta: model=PricingRule; fields="__all__"
class CourierCreateForm(forms.Form):
    name=forms.CharField(max_length=120); email=forms.EmailField(); phone=forms.CharField(max_length=30); vehicle_no=forms.CharField(max_length=50); license_no=forms.CharField(max_length=80); vehicle_type=forms.ChoiceField(choices=Courier.VehicleTypes.choices); current_area=forms.CharField(max_length=120,required=False)


class CourierUpdateForm(forms.ModelForm):
    class Meta:
        model = Courier
        fields = ("name", "email", "phone", "vehicle_no", "license_no", "vehicle_type", "current_area", "joining_date", "status")
        widgets = {
            "joining_date": forms.DateInput(attrs={"type": "date"}),
        }
