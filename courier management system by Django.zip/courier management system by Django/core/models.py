from decimal import Decimal
from datetime import timedelta
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone


class User(AbstractUser):
    class Roles(models.TextChoices):
        CUSTOMER = "CUSTOMER", "Customer"
        ADMIN = "ADMIN", "Admin"
        COURIER = "COURIER", "Courier"
    email = models.EmailField(unique=True)
    role = models.CharField(max_length=20, choices=Roles.choices, default=Roles.CUSTOMER)
    created_at = models.DateTimeField(auto_now_add=True)


class Customer(models.Model):
    customer_id = models.BigAutoField(primary_key=True)
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="customer_profile")
    name = models.CharField(max_length=120)
    phone = models.CharField(max_length=30)
    address = models.TextField()
    def __str__(self): return self.name


class AdminProfile(models.Model):
    admin_id = models.BigAutoField(primary_key=True)
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="admin_profile")
    def __str__(self): return self.user.get_full_name() or self.user.username


class Courier(models.Model):
    class Status(models.TextChoices):
        AVAILABLE = "AVAILABLE", "Available"; BUSY = "BUSY", "Busy"; INACTIVE = "INACTIVE", "Inactive"
    class VehicleTypes(models.TextChoices):
        BIKE = "BIKE", "Bike"; MOTORCYCLE = "MOTORCYCLE", "Motorcycle"; BICYCLE = "BICYCLE", "Bicycle"; VAN = "VAN", "Van"; TRUCK = "TRUCK", "Truck"
    courier_id = models.BigAutoField(primary_key=True)
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="courier_profile")
    name = models.CharField(max_length=120)
    phone = models.CharField(max_length=30)
    email = models.EmailField(blank=True)
    vehicle_no = models.CharField(max_length=50)
    license_no = models.CharField(max_length=80)
    vehicle_type = models.CharField(max_length=20, choices=VehicleTypes.choices, default=VehicleTypes.MOTORCYCLE)
    current_area = models.CharField(max_length=120, blank=True)
    joining_date = models.DateField(default=timezone.localdate)
    profile_photo = models.FileField(upload_to="couriers/", blank=True, null=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.AVAILABLE)
    def __str__(self): return self.name


class Category(models.Model):
    category_id = models.BigAutoField(primary_key=True)
    category_name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    def __str__(self): return self.category_name


class Parcel(models.Model):
    parcel_id = models.BigAutoField(primary_key=True)
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name="parcels")
    name = models.CharField(max_length=150)
    receiver_name = models.CharField(max_length=120, blank=True)
    receiver_phone = models.CharField(max_length=30, blank=True)
    receiver_email = models.EmailField(blank=True)
    receiver_address = models.TextField(blank=True)
    weight = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    quantity = models.PositiveIntegerField(default=1)
    fragile = models.BooleanField(default=False)
    emergency_delivery = models.BooleanField(default=False)
    special_handling = models.BooleanField(default=False)
    description = models.TextField(blank=True)
    delivery_instruction = models.TextField(blank=True)
    destination_division = models.CharField(max_length=50, blank=True)
    destination_district = models.CharField(max_length=80, blank=True)
    destination_area = models.CharField(max_length=120, blank=True)
    base_price = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    # Only parcels/services created through the Admin "Send Parcel" screen are shown as active parcel services.
    is_service = models.BooleanField(default=False)
    def __str__(self): return self.name


class PricingRule(models.Model):
    class Zones(models.TextChoices):
        SAME_AREA = "SAME_AREA", "Same Area"; SAME_CITY = "SAME_CITY", "Same City"; OUTSIDE_CITY = "OUTSIDE_CITY", "Outside City"; REMOTE = "REMOTE", "Remote Area"
    class DeliveryTypes(models.TextChoices):
        STANDARD = "STANDARD", "Standard"; EXPRESS = "EXPRESS", "Express"; EMERGENCY = "EMERGENCY", "Emergency"
    name = models.CharField(max_length=120)
    zone = models.CharField(max_length=20, choices=Zones.choices, default=Zones.SAME_CITY)
    delivery_type = models.CharField(max_length=20, choices=DeliveryTypes.choices, default=DeliveryTypes.STANDARD)
    min_weight = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    max_weight = models.DecimalField(max_digits=8, decimal_places=2, default=9999)
    base_charge = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    per_kg_charge = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    zone_charge = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    express_charge = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    emergency_charge = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    fragile_charge = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    active = models.BooleanField(default=True)
    def __str__(self): return self.name

    @classmethod
    def calculate(cls, weight, zone, delivery_type, fragile=False):
        # Always calculate using the customer's selected weight.
        # The Above 20 KG option is represented by 25 KG in the order form,
        # so pricing rules must cover weights above 20 KG as well.
        weight = max(Decimal("0"), Decimal(str(weight)))

        rule = cls.objects.filter(
            active=True,
            zone=zone,
            delivery_type=delivery_type,
            min_weight__lte=weight,
            max_weight__gte=weight,
        ).order_by("min_weight").first()

        # Fallback to a delivery-type rule if a zone-specific rule is missing.
        if not rule:
            rule = cls.objects.filter(
                active=True,
                delivery_type=delivery_type,
                min_weight__lte=weight,
                max_weight__gte=weight,
            ).order_by("min_weight").first()

        # Never silently create a free shipment when a pricing rule is missing.
        # This fallback also makes Above 20 KG orders billable immediately.
        if not rule:
            zone_charge = {
                cls.Zones.SAME_AREA: Decimal("20.00"),
                cls.Zones.SAME_CITY: Decimal("50.00"),
                cls.Zones.OUTSIDE_CITY: Decimal("100.00"),
                cls.Zones.REMOTE: Decimal("150.00"),
            }.get(zone, Decimal("50.00"))

            base_charge = Decimal("300.00") if weight > Decimal("20") else Decimal("60.00")
            per_kg_charge = Decimal("25.00") if weight > Decimal("20") else Decimal("20.00")
            total = base_charge + (weight * per_kg_charge) + zone_charge

            if delivery_type == cls.DeliveryTypes.EXPRESS:
                total += Decimal("50.00")
            elif delivery_type == cls.DeliveryTypes.EMERGENCY:
                total += Decimal("120.00")
            if fragile:
                total += Decimal("40.00")

            return total.quantize(Decimal("0.01"))

        total = rule.base_charge + (weight * rule.per_kg_charge) + rule.zone_charge
        if delivery_type == cls.DeliveryTypes.EXPRESS:
            total += rule.express_charge
        elif delivery_type == cls.DeliveryTypes.EMERGENCY:
            total += rule.emergency_charge
        if fragile:
            total += rule.fragile_charge
        return total.quantize(Decimal("0.01"))


class Order(models.Model):
    class Status(models.TextChoices):
        PENDING="PENDING","Order Placed"; CONFIRMED="CONFIRMED","Confirmed"; ASSIGNED="ASSIGNED","Courier Assigned"; PICKUP_SCHEDULED="PICKUP_SCHEDULED","Pickup Scheduled"; PICKED_UP="PICKED_UP","Picked Up"; SORTING="SORTING","At Sorting Center"; IN_TRANSIT="IN_TRANSIT","In Transit"; OUT_FOR_DELIVERY="OUT_FOR_DELIVERY","Out for Delivery"; DELIVERED="DELIVERED","Delivered"; FAILED="FAILED","Failed Delivery"; RETURNED="RETURNED","Returned"; CANCELLED="CANCELLED","Cancelled"
    class DeliveryTypes(models.TextChoices):
        STANDARD="STANDARD","Standard"; EXPRESS="EXPRESS","Express"; EMERGENCY="EMERGENCY","Emergency"
    class Zones(models.TextChoices):
        SAME_AREA="SAME_AREA","Same Area"; SAME_CITY="SAME_CITY","Same City"; OUTSIDE_CITY="OUTSIDE_CITY","Outside City"; REMOTE="REMOTE","Remote Area"
    order_id = models.BigAutoField(primary_key=True)
    tracking_number = models.CharField(max_length=40, unique=True, null=True, blank=True)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name="orders")
    order_date = models.DateTimeField(default=timezone.now)
    sender_name = models.CharField(max_length=120, default="")
    sender_phone = models.CharField(max_length=30, default="")
    sender_email = models.EmailField(blank=True)
    pickup_country = models.CharField(max_length=80, default="Bangladesh")
    pickup_division = models.CharField(max_length=100, default="Dhaka")
    pickup_district = models.CharField(max_length=100, default="Dhaka")
    pickup_area = models.CharField(max_length=120, default="")
    pickup_postal_code = models.CharField(max_length=20, default="")
    pickup_address = models.TextField()
    receiver_name = models.CharField(max_length=120, default="")
    receiver_phone = models.CharField(max_length=30, default="")
    delivery_country = models.CharField(max_length=80, default="Bangladesh")
    delivery_division = models.CharField(max_length=100, default="Dhaka")
    delivery_district = models.CharField(max_length=100, default="Dhaka")
    delivery_area = models.CharField(max_length=120, default="")
    delivery_postal_code = models.CharField(max_length=20, default="")
    delivery_address = models.TextField()
    delivery_type = models.CharField(max_length=20, choices=DeliveryTypes.choices, default=DeliveryTypes.STANDARD)
    zone = models.CharField(max_length=20, choices=Zones.choices, default=Zones.SAME_CITY)
    expected_delivery_date = models.DateField(null=True, blank=True)
    total_weight = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    delivery_charge = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    total_amount = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    status = models.CharField(max_length=30, choices=Status.choices, default=Status.PENDING)
    cancellation_reason = models.TextField(blank=True)
    failed_reason = models.CharField(max_length=120, blank=True)
    return_to_sender = models.BooleanField(default=False)
    def __str__(self): return f"ORD-{self.order_id:05d}"

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        if not self.tracking_number:
            date_part = timezone.localtime(self.order_date).strftime("%Y%m%d") if self.order_date else timezone.localdate().strftime("%Y%m%d")
            self.tracking_number = f"CMS-{date_part}-{self.order_id:05d}"
            super().save(update_fields=["tracking_number"])

    class Meta:
        ordering = ["-order_date"]

    @property
    def can_cancel(self): return self.status in {self.Status.PENDING, self.Status.CONFIRMED}


class OrderItem(models.Model):
    order_item_id = models.BigAutoField(primary_key=True)
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
    parcel = models.ForeignKey(Parcel, on_delete=models.PROTECT, related_name="order_items")
    quantity = models.PositiveIntegerField(default=1)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    @property
    def line_total(self): return self.price * self.quantity
    @property
    def total_weight(self): return self.parcel.weight * self.quantity
    def __str__(self): return f"{self.order} - {self.parcel}"


class Payment(models.Model):
    class Methods(models.TextChoices): CASH="CASH","Cash on Delivery"; CARD="CARD","Card / Online Payment"; MOBILE="MOBILE","Mobile Banking"; BANK_TRANSFER="BANK_TRANSFER","Bank Transfer"
    class Payers(models.TextChoices): SENDER="SENDER","Sender"; RECEIVER="RECEIVER","Receiver"
    class Status(models.TextChoices): PENDING="PENDING","Pending"; PAID="PAID","Paid"; FAILED="FAILED","Failed"
    payment_id = models.BigAutoField(primary_key=True)
    order = models.OneToOneField(Order, on_delete=models.CASCADE, related_name="payment")
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    payment_by = models.CharField(max_length=20, choices=Payers.choices, default=Payers.RECEIVER)
    payment_method = models.CharField(max_length=20, choices=Methods.choices, default=Methods.CASH)
    payment_status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    payment_provider = models.CharField(max_length=80, blank=True)
    account_name = models.CharField(max_length=120, blank=True)
    account_number = models.CharField(max_length=60, blank=True)
    bank_name = models.CharField(max_length=120, blank=True)
    branch_name = models.CharField(max_length=120, blank=True)
    routing_number = models.CharField(max_length=30, blank=True)
    payment_note = models.TextField(blank=True)
    paid_at = models.DateTimeField(null=True, blank=True)
    def __str__(self): return f"PAY-{self.payment_id:05d}"


class Delivery(models.Model):
    class Status(models.TextChoices):
        ASSIGNED="ASSIGNED","Courier Assigned"; PICKUP_SCHEDULED="PICKUP_SCHEDULED","Pickup Scheduled"; PICKED_UP="PICKED_UP","Picked Up"; SORTING="SORTING","At Sorting Center"; IN_TRANSIT="IN_TRANSIT","In Transit"; OUT_FOR_DELIVERY="OUT_FOR_DELIVERY","Out for Delivery"; DELIVERED="DELIVERED","Delivered"; FAILED="FAILED","Failed Delivery"; RETURNED="RETURNED","Returned"; CANCELLED="CANCELLED","Cancelled"
    class FailedReasons(models.TextChoices):
        UNAVAILABLE="RECEIVER_UNAVAILABLE","Receiver unavailable"; WRONG_ADDRESS="WRONG_ADDRESS","Wrong address"; UNREACHABLE="PHONE_UNREACHABLE","Phone unreachable"; CUSTOMER_CANCELLED="CUSTOMER_CANCELLED","Customer cancelled"; OTHER="OTHER","Other"
    delivery_id = models.BigAutoField(primary_key=True)
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="deliveries")
    courier = models.ForeignKey(Courier, on_delete=models.PROTECT, related_name="deliveries")
    assigned_date = models.DateTimeField(default=timezone.now)
    pickup_date = models.DateTimeField(null=True, blank=True)
    expected_delivery_date = models.DateField(null=True, blank=True)
    delivery_date = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=30, choices=Status.choices, default=Status.ASSIGNED)
    delivery_charges = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    failed_reason = models.CharField(max_length=40, choices=FailedReasons.choices, blank=True)
    return_to_sender = models.BooleanField(default=False)
    delivered_by = models.CharField(max_length=120, blank=True)
    receiver_confirmation = models.CharField(max_length=255, blank=True)
    proof_photo = models.FileField(upload_to="delivery_proof/", blank=True, null=True)
    proof_signature = models.FileField(upload_to="delivery_signatures/", blank=True, null=True)
    class Meta:
        ordering = ["-delivery_id"]

    def __str__(self): return f"DEL-{self.delivery_id:05d}"


class Tracking(models.Model):
    tracking_id = models.BigAutoField(primary_key=True)
    delivery = models.ForeignKey(Delivery, on_delete=models.CASCADE, related_name="tracking_updates")
    location = models.CharField(max_length=150)
    status = models.CharField(max_length=100)
    update_time = models.DateTimeField(default=timezone.now)
    note = models.TextField(blank=True)
    class Meta: ordering=["-update_time"]
    def __str__(self): return f"TRK-{self.tracking_id:05d}"
