from django.core.management.base import BaseCommand
from django.db import transaction
from core.models import User, Customer, AdminProfile, Courier, PricingRule


class Command(BaseCommand):
    help = "Create demo users, courier data and pricing rules without creating sample parcel services."

    @transaction.atomic
    def handle(self, *args, **options):
        admin, _ = User.objects.get_or_create(
            username="admin",
            defaults={"email": "admin@example.com", "role": User.Roles.ADMIN, "is_staff": True, "is_superuser": True},
        )
        if not admin.has_usable_password():
            admin.set_password("Admin@12345")
            admin.save()
        AdminProfile.objects.get_or_create(user=admin)

        cu, _ = User.objects.get_or_create(
            username="customer",
            defaults={"email": "customer@example.com", "role": User.Roles.CUSTOMER},
        )
        if not cu.has_usable_password():
            cu.set_password("Customer@12345")
            cu.save()
        Customer.objects.get_or_create(
            user=cu,
            defaults={"name": "Demo Customer", "phone": "01700000000", "address": "Mirpur, Dhaka, Bangladesh"},
        )

        couru, _ = User.objects.get_or_create(
            username="courier",
            defaults={"email": "courier@example.com", "role": User.Roles.COURIER},
        )
        if not couru.has_usable_password():
            couru.set_password("Courier@12345")
            couru.save()
        Courier.objects.get_or_create(
            user=couru,
            defaults={
                "name": "Demo Courier",
                "phone": "01800000000",
                "email": "courier@example.com",
                "vehicle_no": "DHAKA-METRO-01",
                "license_no": "LIC-001",
                "vehicle_type": "MOTORCYCLE",
                "current_area": "Mirpur",
            },
        )

        for zone, zcharge in [("SAME_AREA", 20), ("SAME_CITY", 50), ("OUTSIDE_CITY", 100), ("REMOTE", 150)]:
            for dtype in ["STANDARD", "EXPRESS", "EMERGENCY"]:
                PricingRule.objects.update_or_create(
                    name=f"{zone} {dtype}",
                    defaults={
                        "zone": zone,
                        "delivery_type": dtype,
                        "min_weight": 0,
                        "max_weight": 9999,
                        "base_charge": 60,
                        "per_kg_charge": 20,
                        "zone_charge": zcharge,
                        "express_charge": 50,
                        "emergency_charge": 120,
                        "fragile_charge": 40,
                        "active": True,
                    },
                )

        self.stdout.write(self.style.SUCCESS("Demo users and pricing rules ready. No sample parcel services were created."))
