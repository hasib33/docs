from django.db import migrations


PARCEL_TYPES = [
    ("Document", "Documents, letters, certificates and similar paper items.", False, False, False),
    ("Clothing", "Clothes, garments and fabric items.", False, False, False),
    ("Electronics", "Mobile phones, accessories and other electronic items.", False, False, True),
    ("Food", "Packaged and suitable non-perishable food items.", False, False, False),
    ("Glass / Fragile", "Glassware and other fragile items that require careful handling.", True, False, True),
    ("Books", "Books, notebooks and printed materials.", False, False, False),
    ("Small Parcel", "General small parcel items.", False, False, False),
    ("Other", "Other permitted parcel items.", False, False, False),
]


def create_parcel_types(apps, schema_editor):
    Category = apps.get_model("core", "Category")
    Parcel = apps.get_model("core", "Parcel")

    for name, description, fragile, emergency_delivery, special_handling in PARCEL_TYPES:
        category, _ = Category.objects.get_or_create(
            category_name=name,
            defaults={"description": description},
        )
        Parcel.objects.get_or_create(
            category=category,
            name=name,
            is_service=True,
            defaults={
                "description": description,
                "weight": 1,
                "quantity": 1,
                "fragile": fragile,
                "emergency_delivery": emergency_delivery,
                "special_handling": special_handling,
                "base_price": 0,
            },
        )


def remove_parcel_types(apps, schema_editor):
    Category = apps.get_model("core", "Category")
    Parcel = apps.get_model("core", "Parcel")
    names = [item[0] for item in PARCEL_TYPES]
    Parcel.objects.filter(is_service=True, name__in=names).delete()
    Category.objects.filter(category_name__in=names).delete()


class Migration(migrations.Migration):
    dependencies = [
        ("core", "0008_parcel_is_service"),
    ]

    operations = [
        migrations.RunPython(create_parcel_types, remove_parcel_types),
    ]
