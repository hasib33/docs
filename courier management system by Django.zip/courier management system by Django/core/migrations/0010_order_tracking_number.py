from django.db import migrations, models
from django.utils import timezone


def backfill_tracking_numbers(apps, schema_editor):
    Order = apps.get_model("core", "Order")
    for order in Order.objects.filter(tracking_number__isnull=True).order_by("order_id"):
        date_part = timezone.localtime(order.order_date).strftime("%Y%m%d") if order.order_date else timezone.localdate().strftime("%Y%m%d")
        order.tracking_number = f"CMS-{date_part}-{order.order_id:05d}"
        order.save(update_fields=["tracking_number"])


def reverse_tracking_numbers(apps, schema_editor):
    Order = apps.get_model("core", "Order")
    Order.objects.update(tracking_number=None)


class Migration(migrations.Migration):
    dependencies = [("core", "0009_seed_parcel_item_types")]

    operations = [
        migrations.AddField(
            model_name="order",
            name="tracking_number",
            field=models.CharField(blank=True, max_length=40, null=True, unique=True),
        ),
        migrations.RunPython(backfill_tracking_numbers, reverse_tracking_numbers),
    ]
