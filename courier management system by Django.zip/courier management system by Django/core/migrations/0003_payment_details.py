from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("core", "0002_courier_parcel_pricing_order_payment_delivery"),
    ]

    operations = [
        migrations.RemoveField(
            model_name="payment",
            name="transaction_id",
        ),
        migrations.AddField(
            model_name="payment",
            name="payment_provider",
            field=models.CharField(blank=True, max_length=80),
        ),
        migrations.AddField(
            model_name="payment",
            name="account_name",
            field=models.CharField(blank=True, max_length=120),
        ),
        migrations.AddField(
            model_name="payment",
            name="account_number",
            field=models.CharField(blank=True, max_length=60),
        ),
        migrations.AddField(
            model_name="payment",
            name="bank_name",
            field=models.CharField(blank=True, max_length=120),
        ),
        migrations.AddField(
            model_name="payment",
            name="branch_name",
            field=models.CharField(blank=True, max_length=120),
        ),
        migrations.AddField(
            model_name="payment",
            name="routing_number",
            field=models.CharField(blank=True, max_length=30),
        ),
        migrations.AddField(
            model_name="payment",
            name="payment_note",
            field=models.TextField(blank=True),
        ),
        migrations.AlterField(
            model_name="payment",
            name="payment_method",
            field=models.CharField(
                choices=[
                    ("CASH", "Cash on Delivery"),
                    ("CARD", "Card / Online Payment"),
                    ("MOBILE", "Mobile Banking"),
                    ("BANK_TRANSFER", "Bank Transfer"),
                ],
                default="CASH",
                max_length=20,
            ),
        ),
    ]
