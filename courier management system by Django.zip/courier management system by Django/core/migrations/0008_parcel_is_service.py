from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("core", "0007_remove_parcel_size"),
    ]

    operations = [
        migrations.AddField(
            model_name="parcel",
            name="is_service",
            field=models.BooleanField(default=False),
        ),
    ]
