from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('core', '0003_payment_details'),
    ]

    operations = [
        migrations.AddField(
            model_name='parcel',
            name='destination_area',
            field=models.CharField(blank=True, max_length=120),
        ),
        migrations.AddField(
            model_name='parcel',
            name='destination_district',
            field=models.CharField(blank=True, max_length=80),
        ),
        migrations.AddField(
            model_name='parcel',
            name='destination_division',
            field=models.CharField(blank=True, max_length=50),
        ),
        migrations.RemoveField(model_name='parcel', name='declared_value'),
        migrations.RemoveField(model_name='parcel', name='height_cm'),
        migrations.RemoveField(model_name='parcel', name='length_cm'),
        migrations.RemoveField(model_name='parcel', name='width_cm'),
    ]
