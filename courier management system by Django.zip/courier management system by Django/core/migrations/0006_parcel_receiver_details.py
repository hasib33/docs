from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("core", "0005_parcel_receiver_quantity"),
    ]

    operations = [
        migrations.AddField(
            model_name="parcel",
            name="receiver_phone",
            field=models.CharField(blank=True, max_length=30),
        ),
        migrations.AddField(
            model_name="parcel",
            name="receiver_email",
            field=models.EmailField(blank=True, max_length=254),
        ),
        migrations.AddField(
            model_name="parcel",
            name="receiver_address",
            field=models.TextField(blank=True),
        ),
    ]
