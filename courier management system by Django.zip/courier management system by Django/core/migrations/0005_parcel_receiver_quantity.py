from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("core", "0004_parcel_destination_remove_dimensions_declared")]

    operations = [
        migrations.AddField(
            model_name="parcel",
            name="receiver_name",
            field=models.CharField(blank=True, max_length=120),
        ),
        migrations.AddField(
            model_name="parcel",
            name="quantity",
            field=models.PositiveIntegerField(default=1),
        ),
    ]
