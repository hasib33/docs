from django.db import migrations


class Migration(migrations.Migration):
    dependencies = [
        ("core", "0006_parcel_receiver_details"),
    ]

    operations = [
        migrations.RemoveField(
            model_name="parcel",
            name="size",
        ),
    ]
