# Courier Management System - Updated Project Notes

## Main workflow
Customer registers -> selects parcel -> enters sender/receiver Bangladesh address -> selects zone and Standard/Express/Emergency -> selects who pays -> system calculates delivery charge -> order is placed -> Admin assigns courier -> Courier updates delivery status/location -> tracking timeline grows -> delivery/payment completes -> Admin can generate monthly report/PDF.

## Automatic pricing
`PricingRule.calculate()` uses active rules matching weight, zone and delivery type. It adds base charge, per-KG charge, zone charge, Express/Emergency charge and fragile/special-handling charge.

## Status lifecycle
Order Placed -> Confirmed -> Courier Assigned -> Pickup Scheduled -> Picked Up -> At Sorting Center -> In Transit -> Out for Delivery -> Delivered.

Alternative outcomes: Failed Delivery -> Returned, or Cancelled before pickup.

## Payment
- Sender: Cash/Card/Mobile Banking.
- Receiver: Cash on Delivery.
- Payment status is tracked and receiver COD is marked paid when courier records delivery.

## Monthly report
Filter by `YYYY-MM` and export PDF. Report covers order status, parcel quantity, weight, fragile count, delivery types, delivery charges, paid revenue, courier performance, zone summary and payment method summary.


Payment update: Receiver is allowed to select CASH, MOBILE, BANK_TRANSFER, or CARD.
