# Phase 4 - Parcel & Pricing Management

## Added
- Admin parcel/service search and filters.
- Parcel/service edit and archive actions. Archived services are hidden from customer order selection while existing orders remain safe.
- Admin pricing rule search and filters.
- Pricing rule edit and activate/deactivate actions.
- Pricing rule validation for minimum/maximum weight.
- Customer-side live delivery-charge preview based on parcel, weight, quantity, delivery type and pickup/delivery locations.
- Existing server-side `PricingRule.calculate()` remains the authoritative final calculation when an order is submitted.

## No database migration required
Phase 4 uses the existing Parcel and PricingRule fields, so the existing database can be kept.
