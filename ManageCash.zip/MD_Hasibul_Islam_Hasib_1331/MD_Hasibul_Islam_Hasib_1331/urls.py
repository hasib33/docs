"""
URL configuration for MD_Hasibul_Islam_Hasib_1331 project.
"""
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('ManageCash.urls')),
]